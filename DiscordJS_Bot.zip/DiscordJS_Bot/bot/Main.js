const Discord = require('discord.js');
const client = new Discord.Client();

var token = "MzczMTk2NTQ0NzQ2MzIzOTc4.DPS1rQ.zyCZ8PaJGJd0yncVoQEhJEumvpg";
var gameName = "dc";

client.login(token);
client.on('ready', () => {
    console.log('Ready!');
    Discord.Game.name=gameName;
});

client.on('message', msg => {
    console.log('msg: ',msg.content);
    if (msg.content === 'hi') {
      msg.reply('Hallo');
    }
  });

