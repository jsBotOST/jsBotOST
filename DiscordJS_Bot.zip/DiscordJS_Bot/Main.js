const Discord = require('discord.js');
const client = new Discord.Client();

client.on('ready', () => {
    console.log('Ready!');
});

client.login('MzczMTk2NTQ0NzQ2MzIzOTc4.DPS1rQ.zyCZ8PaJGJd0yncVoQEhJEumvpg');